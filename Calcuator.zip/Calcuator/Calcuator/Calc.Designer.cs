﻿namespace Calcuator
{
    partial class Calc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddMinusButton = new System.Windows.Forms.Button();
            this.DecButton = new System.Windows.Forms.Button();
            this.EqualButton = new System.Windows.Forms.Button();
            this.PlusButton = new System.Windows.Forms.Button();
            this.ThreeButton = new System.Windows.Forms.Button();
            this.TwoButton = new System.Windows.Forms.Button();
            this.MinusButton = new System.Windows.Forms.Button();
            this.SixButton = new System.Windows.Forms.Button();
            this.FiveButton = new System.Windows.Forms.Button();
            this.FourButton = new System.Windows.Forms.Button();
            this.NineButton = new System.Windows.Forms.Button();
            this.EightButton = new System.Windows.Forms.Button();
            this.SevenButton = new System.Windows.Forms.Button();
            this.DivideButton = new System.Windows.Forms.Button();
            this.DelButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.CEButton = new System.Windows.Forms.Button();
            this.OneDividesXButton = new System.Windows.Forms.Button();
            this.XPowerYButton = new System.Windows.Forms.Button();
            this.PowerTwoButton = new System.Windows.Forms.Button();
            this.SqrtButton = new System.Windows.Forms.Button();
            this.MultiButton = new System.Windows.Forms.Button();
            this.OneButton = new System.Windows.Forms.Button();
            this.ZeroButton = new System.Windows.Forms.Button();
            this.ShowNumberBox = new System.Windows.Forms.TextBox();
            this.History = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // AddMinusButton
            // 
            this.AddMinusButton.Location = new System.Drawing.Point(12, 341);
            this.AddMinusButton.Name = "AddMinusButton";
            this.AddMinusButton.Size = new System.Drawing.Size(64, 43);
            this.AddMinusButton.TabIndex = 0;
            this.AddMinusButton.Text = "+/-";
            this.AddMinusButton.UseVisualStyleBackColor = true;
            this.AddMinusButton.Click += new System.EventHandler(this.AddMinusButton_Click);
            // 
            // DecButton
            // 
            this.DecButton.Location = new System.Drawing.Point(152, 341);
            this.DecButton.Name = "DecButton";
            this.DecButton.Size = new System.Drawing.Size(64, 43);
            this.DecButton.TabIndex = 2;
            this.DecButton.Text = ".";
            this.DecButton.UseVisualStyleBackColor = true;
            this.DecButton.Click += new System.EventHandler(this.DecButton_Click);
            // 
            // EqualButton
            // 
            this.EqualButton.Location = new System.Drawing.Point(221, 341);
            this.EqualButton.Name = "EqualButton";
            this.EqualButton.Size = new System.Drawing.Size(64, 43);
            this.EqualButton.TabIndex = 3;
            this.EqualButton.Text = "=";
            this.EqualButton.UseVisualStyleBackColor = true;
            this.EqualButton.Click += new System.EventHandler(this.EqualButton_Click);
            // 
            // PlusButton
            // 
            this.PlusButton.Location = new System.Drawing.Point(221, 288);
            this.PlusButton.Name = "PlusButton";
            this.PlusButton.Size = new System.Drawing.Size(64, 43);
            this.PlusButton.TabIndex = 7;
            this.PlusButton.Text = "+";
            this.PlusButton.UseVisualStyleBackColor = true;
            this.PlusButton.Click += new System.EventHandler(this.PlusButton_Click);
            // 
            // ThreeButton
            // 
            this.ThreeButton.Location = new System.Drawing.Point(152, 288);
            this.ThreeButton.Name = "ThreeButton";
            this.ThreeButton.Size = new System.Drawing.Size(64, 43);
            this.ThreeButton.TabIndex = 6;
            this.ThreeButton.Text = "3";
            this.ThreeButton.UseVisualStyleBackColor = true;
            this.ThreeButton.Click += new System.EventHandler(this.ThreeButton_Click);
            // 
            // TwoButton
            // 
            this.TwoButton.Location = new System.Drawing.Point(82, 288);
            this.TwoButton.Name = "TwoButton";
            this.TwoButton.Size = new System.Drawing.Size(64, 43);
            this.TwoButton.TabIndex = 5;
            this.TwoButton.Text = "2";
            this.TwoButton.UseVisualStyleBackColor = true;
            this.TwoButton.Click += new System.EventHandler(this.TwoButton_Click);
            // 
            // MinusButton
            // 
            this.MinusButton.Location = new System.Drawing.Point(221, 236);
            this.MinusButton.Name = "MinusButton";
            this.MinusButton.Size = new System.Drawing.Size(64, 43);
            this.MinusButton.TabIndex = 11;
            this.MinusButton.Text = "-";
            this.MinusButton.UseVisualStyleBackColor = true;
            this.MinusButton.Click += new System.EventHandler(this.MinusButton_Click);
            // 
            // SixButton
            // 
            this.SixButton.Location = new System.Drawing.Point(152, 236);
            this.SixButton.Name = "SixButton";
            this.SixButton.Size = new System.Drawing.Size(64, 43);
            this.SixButton.TabIndex = 10;
            this.SixButton.Text = "6";
            this.SixButton.UseVisualStyleBackColor = true;
            this.SixButton.Click += new System.EventHandler(this.SixButton_Click);
            // 
            // FiveButton
            // 
            this.FiveButton.Location = new System.Drawing.Point(82, 236);
            this.FiveButton.Name = "FiveButton";
            this.FiveButton.Size = new System.Drawing.Size(64, 43);
            this.FiveButton.TabIndex = 9;
            this.FiveButton.Text = "5";
            this.FiveButton.UseVisualStyleBackColor = true;
            this.FiveButton.Click += new System.EventHandler(this.FiveButton_Click);
            // 
            // FourButton
            // 
            this.FourButton.Location = new System.Drawing.Point(12, 236);
            this.FourButton.Name = "FourButton";
            this.FourButton.Size = new System.Drawing.Size(64, 43);
            this.FourButton.TabIndex = 8;
            this.FourButton.Text = "4";
            this.FourButton.UseVisualStyleBackColor = true;
            this.FourButton.Click += new System.EventHandler(this.FourButton_Click);
            // 
            // NineButton
            // 
            this.NineButton.Location = new System.Drawing.Point(152, 185);
            this.NineButton.Name = "NineButton";
            this.NineButton.Size = new System.Drawing.Size(64, 43);
            this.NineButton.TabIndex = 14;
            this.NineButton.Text = "9";
            this.NineButton.UseVisualStyleBackColor = true;
            this.NineButton.Click += new System.EventHandler(this.NineButton_Click);
            // 
            // EightButton
            // 
            this.EightButton.Location = new System.Drawing.Point(82, 185);
            this.EightButton.Name = "EightButton";
            this.EightButton.Size = new System.Drawing.Size(64, 43);
            this.EightButton.TabIndex = 13;
            this.EightButton.Text = "8";
            this.EightButton.UseVisualStyleBackColor = true;
            this.EightButton.Click += new System.EventHandler(this.EightButton_Click);
            // 
            // SevenButton
            // 
            this.SevenButton.Location = new System.Drawing.Point(12, 185);
            this.SevenButton.Name = "SevenButton";
            this.SevenButton.Size = new System.Drawing.Size(64, 43);
            this.SevenButton.TabIndex = 12;
            this.SevenButton.Text = "7";
            this.SevenButton.UseVisualStyleBackColor = true;
            this.SevenButton.Click += new System.EventHandler(this.SevenButton_Click);
            // 
            // DivideButton
            // 
            this.DivideButton.Location = new System.Drawing.Point(221, 134);
            this.DivideButton.Name = "DivideButton";
            this.DivideButton.Size = new System.Drawing.Size(64, 43);
            this.DivideButton.TabIndex = 19;
            this.DivideButton.Text = "/";
            this.DivideButton.UseVisualStyleBackColor = true;
            this.DivideButton.Click += new System.EventHandler(this.DivideButton_Click);
            // 
            // DelButton
            // 
            this.DelButton.Location = new System.Drawing.Point(152, 134);
            this.DelButton.Name = "DelButton";
            this.DelButton.Size = new System.Drawing.Size(64, 43);
            this.DelButton.TabIndex = 18;
            this.DelButton.Text = "Del.";
            this.DelButton.UseVisualStyleBackColor = true;
            this.DelButton.Click += new System.EventHandler(this.DelButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(82, 134);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(64, 43);
            this.ClearButton.TabIndex = 17;
            this.ClearButton.Text = "C";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // CEButton
            // 
            this.CEButton.Location = new System.Drawing.Point(12, 134);
            this.CEButton.Name = "CEButton";
            this.CEButton.Size = new System.Drawing.Size(64, 43);
            this.CEButton.TabIndex = 16;
            this.CEButton.Text = "CE";
            this.CEButton.UseVisualStyleBackColor = true;
            this.CEButton.Click += new System.EventHandler(this.CEButton_Click);
            // 
            // OneDividesXButton
            // 
            this.OneDividesXButton.Location = new System.Drawing.Point(221, 84);
            this.OneDividesXButton.Name = "OneDividesXButton";
            this.OneDividesXButton.Size = new System.Drawing.Size(64, 43);
            this.OneDividesXButton.TabIndex = 23;
            this.OneDividesXButton.Text = "1/x";
            this.OneDividesXButton.UseVisualStyleBackColor = true;
            this.OneDividesXButton.Click += new System.EventHandler(this.OneDividesXButton_Click);
            // 
            // XPowerYButton
            // 
            this.XPowerYButton.Location = new System.Drawing.Point(152, 84);
            this.XPowerYButton.Name = "XPowerYButton";
            this.XPowerYButton.Size = new System.Drawing.Size(64, 43);
            this.XPowerYButton.TabIndex = 22;
            this.XPowerYButton.Text = "x^y";
            this.XPowerYButton.UseVisualStyleBackColor = true;
            this.XPowerYButton.Click += new System.EventHandler(this.XPowerYButton_Click);
            // 
            // PowerTwoButton
            // 
            this.PowerTwoButton.Location = new System.Drawing.Point(82, 84);
            this.PowerTwoButton.Name = "PowerTwoButton";
            this.PowerTwoButton.Size = new System.Drawing.Size(64, 43);
            this.PowerTwoButton.TabIndex = 21;
            this.PowerTwoButton.Text = "x^2";
            this.PowerTwoButton.UseVisualStyleBackColor = true;
            this.PowerTwoButton.Click += new System.EventHandler(this.PowerTwoButton_Click);
            // 
            // SqrtButton
            // 
            this.SqrtButton.Location = new System.Drawing.Point(12, 84);
            this.SqrtButton.Name = "SqrtButton";
            this.SqrtButton.Size = new System.Drawing.Size(64, 43);
            this.SqrtButton.TabIndex = 20;
            this.SqrtButton.Text = "Sqrt";
            this.SqrtButton.UseVisualStyleBackColor = true;
            this.SqrtButton.Click += new System.EventHandler(this.SqrtButton_Click);
            // 
            // MultiButton
            // 
            this.MultiButton.Location = new System.Drawing.Point(221, 183);
            this.MultiButton.Name = "MultiButton";
            this.MultiButton.Size = new System.Drawing.Size(64, 43);
            this.MultiButton.TabIndex = 24;
            this.MultiButton.Text = "X";
            this.MultiButton.UseVisualStyleBackColor = true;
            this.MultiButton.Click += new System.EventHandler(this.MultiButton_Click);
            // 
            // OneButton
            // 
            this.OneButton.Location = new System.Drawing.Point(12, 288);
            this.OneButton.Name = "OneButton";
            this.OneButton.Size = new System.Drawing.Size(64, 43);
            this.OneButton.TabIndex = 25;
            this.OneButton.Text = "1";
            this.OneButton.UseVisualStyleBackColor = true;
            this.OneButton.Click += new System.EventHandler(this.OneButton_Click);
            // 
            // ZeroButton
            // 
            this.ZeroButton.Location = new System.Drawing.Point(82, 342);
            this.ZeroButton.Name = "ZeroButton";
            this.ZeroButton.Size = new System.Drawing.Size(64, 43);
            this.ZeroButton.TabIndex = 26;
            this.ZeroButton.Text = "0";
            this.ZeroButton.UseVisualStyleBackColor = true;
            this.ZeroButton.Click += new System.EventHandler(this.ZeroButton_Click);
            // 
            // ShowNumberBox
            // 
            this.ShowNumberBox.Font = new System.Drawing.Font("Comic Sans MS", 27F);
            this.ShowNumberBox.Location = new System.Drawing.Point(12, 19);
            this.ShowNumberBox.Name = "ShowNumberBox";
            this.ShowNumberBox.ReadOnly = true;
            this.ShowNumberBox.Size = new System.Drawing.Size(273, 58);
            this.ShowNumberBox.TabIndex = 27;
            this.ShowNumberBox.Text = "0";
            this.ShowNumberBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ShowNumberBox.TextChanged += new System.EventHandler(this.ShowNumberBox_TextChanged);
            this.ShowNumberBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // History
            // 
            this.History.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.History.Location = new System.Drawing.Point(296, 19);
            this.History.Multiline = true;
            this.History.Name = "History";
            this.History.ReadOnly = true;
            this.History.Size = new System.Drawing.Size(145, 366);
            this.History.TabIndex = 28;
            this.History.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.History.TextChanged += new System.EventHandler(this.History_TextChanged_1);
            this.History.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress);
            // 
            // Calc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 397);
            this.Controls.Add(this.History);
            this.Controls.Add(this.ShowNumberBox);
            this.Controls.Add(this.ZeroButton);
            this.Controls.Add(this.OneButton);
            this.Controls.Add(this.MultiButton);
            this.Controls.Add(this.OneDividesXButton);
            this.Controls.Add(this.XPowerYButton);
            this.Controls.Add(this.PowerTwoButton);
            this.Controls.Add(this.SqrtButton);
            this.Controls.Add(this.DivideButton);
            this.Controls.Add(this.DelButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.CEButton);
            this.Controls.Add(this.NineButton);
            this.Controls.Add(this.EightButton);
            this.Controls.Add(this.SevenButton);
            this.Controls.Add(this.MinusButton);
            this.Controls.Add(this.SixButton);
            this.Controls.Add(this.FiveButton);
            this.Controls.Add(this.FourButton);
            this.Controls.Add(this.PlusButton);
            this.Controls.Add(this.ThreeButton);
            this.Controls.Add(this.TwoButton);
            this.Controls.Add(this.EqualButton);
            this.Controls.Add(this.DecButton);
            this.Controls.Add(this.AddMinusButton);
            this.Name = "Calc";
            this.Text = "C# Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddMinusButton;
        private System.Windows.Forms.Button DecButton;
        private System.Windows.Forms.Button EqualButton;
        private System.Windows.Forms.Button PlusButton;
        private System.Windows.Forms.Button ThreeButton;
        private System.Windows.Forms.Button TwoButton;
        private System.Windows.Forms.Button MinusButton;
        private System.Windows.Forms.Button SixButton;
        private System.Windows.Forms.Button FiveButton;
        private System.Windows.Forms.Button FourButton;
        private System.Windows.Forms.Button NineButton;
        private System.Windows.Forms.Button EightButton;
        private System.Windows.Forms.Button SevenButton;
        private System.Windows.Forms.Button DivideButton;
        private System.Windows.Forms.Button DelButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button CEButton;
        private System.Windows.Forms.Button OneDividesXButton;
        private System.Windows.Forms.Button XPowerYButton;
        private System.Windows.Forms.Button PowerTwoButton;
        private System.Windows.Forms.Button SqrtButton;
        private System.Windows.Forms.Button MultiButton;
        private System.Windows.Forms.Button OneButton;
        private System.Windows.Forms.Button ZeroButton;
        private System.Windows.Forms.TextBox ShowNumberBox;
        private System.Windows.Forms.TextBox History;
    }
}

