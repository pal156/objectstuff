﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calcuator
{
    public partial class Calc : Form
    {
        double num1 = 0.0;
        double num2 = 0.0;
        decimal check = 0;
        string op = null;
        int extra = 0;
        double minus = 0;
        double add = 0;
        double divde = 0;
        double star = 0;
        double xy = 0;


        public Calc()
        {
            InitializeComponent();
        }

#pragma warning disable CS0108 // Member hides inherited member; missing new keyword
        private void KeyPress(object sender, KeyPressEventArgs e)
#pragma warning restore CS0108 // Member hides inherited member; missing new keyword
        {
            if (e.KeyChar == 48) // 0
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "0";
                    History.Text = "0";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "0";
                        History.Text = History.Text + "0";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "0";
                        History.Text = History.Text + "0";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 49) // 1
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "1";
                    History.Text = "1";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "1";
                        History.Text = History.Text + "1";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "1";
                        History.Text = History.Text + "1";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 50) // 2
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "2";
                    History.Text = "2";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "2";
                        History.Text = History.Text + "2";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "2";
                        History.Text = History.Text + "2";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 51) // 3
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "3";
                    History.Text = "3";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "3";
                        History.Text = History.Text + "3";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "3";
                        History.Text = History.Text + "3";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 52) // 4
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "4";
                    History.Text = "4";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "4";
                        History.Text = History.Text + "4";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "4";
                        History.Text = History.Text + "4";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 53) // 5
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "5";
                    History.Text = "5";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "5";
                        History.Text = History.Text + "5";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "5";
                        History.Text = History.Text + "5";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 54) // 6
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "6";
                    History.Text = "6";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "6";
                        History.Text = History.Text + "6";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "6";
                        History.Text = History.Text + "6";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 55) // 7
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "7";
                    History.Text = "7";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "7";
                        History.Text = History.Text + "7";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "7";
                        History.Text = History.Text + "7";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 56) // 8
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "8";
                    History.Text = "8";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "8";
                        History.Text = History.Text + "8";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "8";
                        History.Text = History.Text + "8";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 57) // 9
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "9";
                    History.Text = "9";
                }
                else
                {
                    if (extra == 1)
                    {
                        ShowNumberBox.Text = "9";
                        History.Text = History.Text + "9";
                        //History.Text = "0" + History.Text;
                    }
                    else
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text + "9";
                        History.Text = History.Text + "9";
                        //History.Text = "0" + History.Text;
                    }
                }
                extra = 0;
            }

            if (e.KeyChar == 46) //Decimal
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "0.";
                    History.Text = ShowNumberBox.Text;
                }
                else if (Decimal.TryParse(ShowNumberBox.Text, out check))
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + ".";
                    History.Text = ShowNumberBox.Text;

                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text;
                }
                extra = 0;
            }

            if (e.KeyChar == 43) // Plus
            {
                if (add == 0.0)
                {
                    num1 = Convert.ToDouble(ShowNumberBox.Text);
                    History.Text = History.Text + " + ";
                    add = 1;
                }
                else if (extra == 0)
                {
                    History.Text = History.Text + " + ";
                    num1 = num1 + Convert.ToDouble(ShowNumberBox.Text);
                    ShowNumberBox.Text = Convert.ToString(num1);
                    minus = 0;
                    star = 0;
                    divde = 0;
                    xy = 0;
                }
                op = "+";
                extra = 1;
            }

            if (e.KeyChar == 45) // Subtraction
            {
                if (minus == 0)
                {
                    num1 = Convert.ToDouble(ShowNumberBox.Text);
                    History.Text = History.Text + " - ";
                    minus = 1;
                }
                else if (extra == 0)
                {
                    History.Text = History.Text + " - ";
                    num1 = num1 - Convert.ToDouble(ShowNumberBox.Text);
                    ShowNumberBox.Text = Convert.ToString(num1);
                    add = 0;
                    divde = 0;
                    star = 0;
                    xy = 0;
                }
                op = "-";
                extra = 1;
            }

            if (e.KeyChar == 92) //PLUS AND MINUS
            {
                if(ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                    ShowNumberBox.Text = "0";
                }
            else
                {
                    if (ShowNumberBox.Text.StartsWith("-"))
                    {
                        ShowNumberBox.Text = ShowNumberBox.Text.Substring(1);
                        History.Text = History.Text.Substring(1);
                    }
                    else
                    {
                        ShowNumberBox.Text = "-" + ShowNumberBox.Text;
                        History.Text = "-" + History.Text;
                    }
                }
            }

            if (e.KeyChar == 42) // TIMES
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "0";
                }
                else if (star == 0.0)
                {
                    num1 = Convert.ToDouble(ShowNumberBox.Text);
                    //History.Text = " * " + History.Text;
                    History.Text = History.Text + " * ";
                    star = 1;
                }
                else if (extra == 0)
                {
                    //History.Text = " * " + History.Text;
                    History.Text = History.Text + " * ";
                    num1 = num1 * Convert.ToDouble(ShowNumberBox.Text);
                    ShowNumberBox.Text = Convert.ToString(num1);
                    divde = 0;
                    add = 0;
                    minus = 0;
                    xy = 0;

                }
                op = "*";
                extra = 1;
            }

            if (e.KeyChar == 47) // divisoin
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "Error, Clear";
                }
                else if (divde == 0.0)
                {
                    num1 = Convert.ToDouble(ShowNumberBox.Text);
                    History.Text = History.Text + " / ";
                    divde = 1;

                }
                else if (extra == 0)
                {
                    History.Text = History.Text + " / ";
                    num1 = num1 / Convert.ToDouble(ShowNumberBox.Text);
                    ShowNumberBox.Text = Convert.ToString(num1);

                    minus = 0;
                    star = 0;
                    add = 0;
                    xy = 0;
                }
                op = "/";
                extra = 1;

            }

            if (e.KeyChar == 94) //X^Y 
            {
                if (xy == 0)
                {
                    num1 = Convert.ToDouble(ShowNumberBox.Text);
                    xy = 1;
                    History.Text = History.Text + " ^ ";
                }
                else if (extra == 0)
                {
                    History.Text = History.Text + " ^ ";
                    num1 = Math.Pow(num1, Convert.ToDouble(ShowNumberBox.Text));
                    ShowNumberBox.Text = Convert.ToString(num1);
                    divde = 0;
                    star = 0;
                    add = 0;
                    minus = 0;
                }
                extra = 1;
                op = "xy";

            }

            if (e.KeyChar == 126) //SQRT
            {
                if (ShowNumberBox.Text.StartsWith("-"))
                {
                    ShowNumberBox.Text = "Error, Clear";
                }
                else if (extra == 0)
                {

                    num1 = Convert.ToDouble(ShowNumberBox.Text);
                    History.Text = "Sqrt( " + History.Text + " )" + Environment.NewLine;
                    num1 = Math.Sqrt(num1);

                    ShowNumberBox.Text = Convert.ToString(num1);

                    divde = 0;
                    star = 0;
                    add = 0;
                    minus = 0;
                    xy = 0;
                }
                extra = 1;
                op = "sqrt";

            }

            if (e.KeyChar == 08) // Backspace
            {
                if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
                {
                    ShowNumberBox.Text = "0";
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text.Remove(ShowNumberBox.Text.Length - 1);
                    History.Text = History.Text.Remove(History.Text.Length - 1);
                    if (ShowNumberBox.Text == null || ShowNumberBox.Text == "")
                    {
                        ShowNumberBox.Text = "0";
                        History.Text = null;
                    }
                }

            }

            if(e.KeyChar == 99) // clear
            {
                ShowNumberBox.Text = "0";
                num1 = 0;
                num2 = 0;
                divde = 0;
                star = 0;
                add = 0;
                minus = 0;
                extra = 0;
                xy = 0;
                History.Text = null;
                op = null;
            }

            if (e.KeyChar == 118) // Clear Entry
            {
                ShowNumberBox.Text = "0";
                History.Text = Convert.ToString(num1);
            }

            if (e.KeyChar == 13) // Equal
            {
                if (op == "+")
                {
                    num2 = num1 + Convert.ToDouble(ShowNumberBox.Text);
                    History.Text = ShowNumberBox.Text + " + " + Convert.ToDouble(num1);
                    ShowNumberBox.Text = Convert.ToString(num2);
                    History.Text = History.Text + " = " + ShowNumberBox.Text + Environment.NewLine;
                    minus = 0;
                    star = 0;
                    divde = 0;
                    xy = 0;
                }

                if (op == "-")
                {
                    num2 = Convert.ToDouble(ShowNumberBox.Text) - num1;
                    History.Text = ShowNumberBox.Text + " - " + Convert.ToDouble(num1);
                    ShowNumberBox.Text = Convert.ToString(num2);
                    History.Text = History.Text + " = " + ShowNumberBox.Text + Environment.NewLine;
                    add = 0;
                    divde = 0;
                    star = 0;
                    xy = 0;
                }

                if (op == "/")
                {
                    num2 = Convert.ToDouble(ShowNumberBox.Text) / num1;
                    History.Text = ShowNumberBox.Text + " / " + Convert.ToDouble(num1);
                    ShowNumberBox.Text = Convert.ToString(num2);
                    History.Text = History.Text + " = " + ShowNumberBox.Text + Environment.NewLine;
                    minus = 0;
                    star = 0;
                    add = 0;
                    xy = 0;
                }

                if (op == "*")
                {
                    num2 = num1 * Convert.ToDouble(ShowNumberBox.Text);
                    History.Text = ShowNumberBox.Text + " * " + Convert.ToString(num1);
                    ShowNumberBox.Text = Convert.ToString(num2);
                    History.Text = History.Text + " = " + ShowNumberBox.Text + Environment.NewLine;
                    divde = 0;
                    add = 0;
                    minus = 0;
                    xy = 0;
                }

                if (op == "xy")
                {
                    num2 = Math.Pow(num1, Convert.ToDouble(ShowNumberBox.Text));
                    History.Text = ShowNumberBox.Text + " ^ " + Convert.ToString(num1) + Environment.NewLine;
                    ShowNumberBox.Text = Convert.ToString(num2);
                    divde = 0;
                    star = 0;
                    add = 0;
                    minus = 0;
                }

                if (op == "sqrt")
                {

                    num1 = Math.Sqrt(num1);
                    History.Text = "Sqrt ( " + Convert.ToString(num1) + " ) " + Environment.NewLine;
                    ShowNumberBox.Text = Convert.ToString(num1);

                    divde = 0;
                    star = 0;
                    add = 0;
                    minus = 0;
                    xy = 0;
                }

                if (op == "pow")
                {
                    num1 = Math.Pow(num1, 2);
                    History.Text = Convert.ToString(num1) + " ^ 2" + Environment.NewLine;
                    ShowNumberBox.Text = Convert.ToString(num1);

                    divde = 0;
                    star = 0;
                    add = 0;
                    minus = 0;
                    xy = 0;
                }

                if (op == "1/x")
                {
                    History.Text = "1 / " + ShowNumberBox.Text + Environment.NewLine;
                    num1 = 1 / Convert.ToDouble(ShowNumberBox.Text);
                    ShowNumberBox.Text = Convert.ToString(num1);

                    divde = 0;
                    star = 0;
                    add = 0;
                    minus = 0;
                    xy = 0;
                }
            }

        }

        private void AddMinusButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "0";
            }
            else
            {
                if(ShowNumberBox.Text.StartsWith("-"))
                {
                    ShowNumberBox.Text = ShowNumberBox.Text.Substring(1);
                    History.Text = History.Text.Substring(1);
                }
                else
                {
                    ShowNumberBox.Text = "-" + ShowNumberBox.Text;
                    History.Text = "-" + History.Text;
                }
            }


        }

        private void DecButton_Click(object sender, EventArgs e)
        {

            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "0.";
                History.Text = ShowNumberBox.Text;
            }
            else if(Decimal.TryParse(ShowNumberBox.Text, out check))
            {
                ShowNumberBox.Text = ShowNumberBox.Text + ".";
                History.Text = ShowNumberBox.Text;
                
            }
            else
            {
                ShowNumberBox.Text = ShowNumberBox.Text;
            }
        }

        private void EqualButton_Click(object sender, EventArgs e)
        {
            if (op == "+")
            {
                num2 = num1 + Convert.ToDouble(ShowNumberBox.Text);
                History.Text = ShowNumberBox.Text + " + " + Convert.ToDouble(num1);
                ShowNumberBox.Text = Convert.ToString(num2);
                History.Text = History.Text + " = " + ShowNumberBox.Text + Environment.NewLine;
                minus = 0;
                star = 0;
                divde = 0;
                xy = 0;
            }

            if (op == "-")
            {
                num2 = Convert.ToDouble(ShowNumberBox.Text) - num1;
                History.Text = ShowNumberBox.Text + " - " + Convert.ToDouble(num1);
                ShowNumberBox.Text = Convert.ToString(num2);
                History.Text = History.Text + " = " + ShowNumberBox.Text + Environment.NewLine;
                add = 0;
                divde = 0;
                star = 0;
                xy = 0;
            }

            if (op == "/")
            {
                num2 = Convert.ToDouble(ShowNumberBox.Text) / num1;
                History.Text = ShowNumberBox.Text + " / " + Convert.ToDouble(num1);
                ShowNumberBox.Text = Convert.ToString(num2);
                History.Text = History.Text + " = " + ShowNumberBox.Text + Environment.NewLine;
                minus = 0;
                star = 0;
                add = 0;
                xy = 0;
            }

            if (op == "*")
            {
                num2 = num1 * Convert.ToDouble(ShowNumberBox.Text);
                History.Text = ShowNumberBox.Text + " * " + Convert.ToString(num1);
                ShowNumberBox.Text = Convert.ToString(num2);
                History.Text = History.Text + " = " + ShowNumberBox.Text + Environment.NewLine; 
                divde = 0;
                add = 0;
                minus = 0;
                xy = 0;
            }

            if (op == "xy")
            {
                num2 = Math.Pow(num1, Convert.ToDouble(ShowNumberBox.Text));
                History.Text = ShowNumberBox.Text + " ^ " + Convert.ToString(num1) + Environment.NewLine;
                ShowNumberBox.Text = Convert.ToString(num2);
                divde = 0;
                star = 0;
                add = 0;
                minus = 0;
            }

            if (op == "sqrt")
            {
                
                num1 = Math.Sqrt(num1);
                History.Text = "Sqrt ( " + Convert.ToString(num1) + " ) " + Environment.NewLine;
                ShowNumberBox.Text = Convert.ToString(num1);

                divde = 0;
                star = 0;
                add = 0;
                minus = 0;
                xy = 0;
            }

            if (op == "pow")
            {
                num1 = Math.Pow(num1, 2);
                History.Text = Convert.ToString(num1) + " ^ 2" + Environment.NewLine;
                ShowNumberBox.Text = Convert.ToString(num1);

                divde = 0;
                star = 0;
                add = 0;
                minus = 0;
                xy = 0;
            }

            if (op == "1/x")
            {
                History.Text = "1 / " + ShowNumberBox.Text + Environment.NewLine;
                num1 = 1 / Convert.ToDouble(ShowNumberBox.Text);
                ShowNumberBox.Text = Convert.ToString(num1);

                divde = 0;
                star = 0;
                add = 0;
                minus = 0;
                xy = 0;
            }

            
        }

        private void EightButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text !=null)
            {
                ShowNumberBox.Text = "8";
                History.Text = "8";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "8";
                    History.Text = History.Text + "8";
                    //History.Text = "8" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "8";
                    History.Text = History.Text + "8";
                    //History.Text = "8" + History.Text;
                }
            }
            extra = 0;
        }

        private void TwoButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "2";
                History.Text = "2";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "2";
                    History.Text = History.Text + "2";
                    //History.Text = "2" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "2";
                    History.Text = History.Text + "2";
                    //History.Text = "2" + History.Text;
                }
            }
            extra = 0;
        }

        private void ThreeButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "3";
                History.Text = "3";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "3";
                    History.Text = History.Text + "3";
                    //History.Text = "3" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "3";
                    History.Text = History.Text + "3";
                    //History.Text = "3" + History.Text;
                }
            }
            extra = 0;
        }

        private void PlusButton_Click(object sender, EventArgs e)
        {
             if (add == 0.0)
             {
                num1 = Convert.ToDouble(ShowNumberBox.Text);
                History.Text = History.Text + " + ";
                add = 1;
             }
             else if (extra == 0)
             {
                History.Text = History.Text + " + ";
                num1 = num1 + Convert.ToDouble(ShowNumberBox.Text);
                ShowNumberBox.Text = Convert.ToString(num1);
                minus = 0;
                star = 0;
                divde = 0;
                xy = 0;
            }
            op = "+";
            extra = 1;
        }

        private void FourButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "4";
                History.Text = "4";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "4";
                    History.Text = History.Text + "4";
                    //History.Text = "4" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "4";
                    History.Text = History.Text + "4";
                    //History.Text = "4" + History.Text;
                }
            }
            extra = 0;
        }

        private void FiveButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "5";
                History.Text = "5";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "5";
                    History.Text = History.Text + "5";
                    //History.Text = "5" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "5";
                    History.Text = History.Text + "5";
                    //History.Text = "5" + History.Text;
                }
            }
            extra = 0;
        }

        private void SixButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "6";
                History.Text = "6";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "6";
                    History.Text = History.Text + "6";
                    //History.Text = "6" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "6";
                    History.Text = History.Text + "6";
                    //History.Text = "6" + History.Text;
                }
            }
            extra = 0;
        }

        private void MinusButton_Click(object sender, EventArgs e)
        {
            
            if (minus == 0)
            {
                num1 = Convert.ToDouble(ShowNumberBox.Text);
                History.Text = History.Text + " - ";
                minus = 1;
            }
            else if (extra == 0)
            {
                History.Text = History.Text + " - ";
                num1 = num1 - Convert.ToDouble(ShowNumberBox.Text);
                ShowNumberBox.Text = Convert.ToString(num1);
                add = 0;
                divde = 0;
                star = 0;
                xy = 0;
            }
            op = "-";
            extra = 1;
        }

        private void SevenButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "7";
                History.Text = "7";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "7";
                    History.Text = History.Text + "7";
                    //History.Text = "7" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "7";
                    History.Text = History.Text + "7";
                    //History.Text = "7" + History.Text;
                }
            }
            extra = 0;
        }

        private void NineButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "9";
                History.Text = "9";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "9";
                    History.Text = History.Text + "9";
                    //History.Text = "9" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "9";
                    History.Text = History.Text + "9";
                    //History.Text = "9" + History.Text;
                }
            }
            extra = 0;
        }

        private void CEButton_Click(object sender, EventArgs e)
        {
            ShowNumberBox.Text = "0";
            History.Text = Convert.ToString(num1);
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            ShowNumberBox.Text = "0";
            num1 = 0;
            num2 = 0;
            divde = 0;
            star = 0;
            add = 0;
            minus = 0;
            extra = 0;
            xy = 0;
            History.Text = null;
            op = null;
        }

        private void DelButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "0";
            }
            else
            {
                ShowNumberBox.Text = ShowNumberBox.Text.Remove(ShowNumberBox.Text.Length - 1);
                History.Text = History.Text.Remove(History.Text.Length - 1);
                if (ShowNumberBox.Text == null || ShowNumberBox.Text == "")
                {
                    ShowNumberBox.Text = "0";
                    History.Text = null;
                }
            }
        }

        private void DivideButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "Error, Clear";
            }
            else if (divde == 0.0)
            {
                num1 = Convert.ToDouble(ShowNumberBox.Text);
                History.Text = History.Text + " / ";
                divde = 1;
                
            }
            else if (extra == 0)
            {
                History.Text = History.Text + " / ";
                num1 = num1 / Convert.ToDouble(ShowNumberBox.Text);
                ShowNumberBox.Text = Convert.ToString(num1);
                
                minus = 0;
                star = 0;
                add = 0;
                xy = 0;
            }
            op = "/";
            extra = 1;
        }

        private void SqrtButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text.StartsWith("-"))
            {
                ShowNumberBox.Text = "Error, Clear";
            }
            else if (extra == 0)
            {

                num1 = Convert.ToDouble(ShowNumberBox.Text);
                History.Text = "Sqrt( " + History.Text + " )" + Environment.NewLine;
                num1 = Math.Sqrt(num1);

                ShowNumberBox.Text = Convert.ToString(num1);
                
                divde = 0;
                star = 0;
                add = 0;
                minus = 0;
                xy = 0;
            }
            extra = 1;
            op = "sqrt";
        }

        private void PowerTwoButton_Click(object sender, EventArgs e)
        {
            
            num1 = Convert.ToDouble(ShowNumberBox.Text);
            History.Text = History.Text + " ^ 2" + Environment.NewLine;
            num1 = Math.Pow(num1, 2);

            ShowNumberBox.Text = Convert.ToString(num1);
            
            divde = 0;
            star = 0;
            add = 0;
            minus = 0;
            xy = 0;

            extra = 1;
            op = "pow";
        }

        private void XPowerYButton_Click(object sender, EventArgs e)
        {
            if (xy == 0)
            {
                num1 = Convert.ToDouble(ShowNumberBox.Text);
                xy = 1;
                History.Text = History.Text + " ^ ";
            }
            else if (extra == 0)
            {
                History.Text = History.Text + " ^ ";
                num1 = Math.Pow(num1, Convert.ToDouble(ShowNumberBox.Text));
                ShowNumberBox.Text = Convert.ToString(num1);
                divde = 0;
                star = 0;
                add = 0;
                minus = 0;
            }
            extra = 1;
            op = "xy";
        }

        private void OneDividesXButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "Error, Clear";
            }
            else
            {
                
                num1 = 1 / Convert.ToDouble(ShowNumberBox.Text);
                History.Text = "1 / " + ShowNumberBox.Text + Environment.NewLine;
                ShowNumberBox.Text = Convert.ToString(num1);
                
                divde = 0;
                star = 0;
                add = 0;
                minus = 0;
                xy = 0;
            }
            extra = 1;
            op = "1/x";
        }

        private void MultiButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "0";
            }
            else if (star == 0.0)
            {
                num1 = Convert.ToDouble(ShowNumberBox.Text);
                //History.Text = " * " + History.Text;
                History.Text = History.Text + " * ";
                star = 1;
            }
            else if (extra == 0)
            {
                //History.Text = " * " + History.Text;
                History.Text = History.Text + " * ";
                num1 = num1 * Convert.ToDouble(ShowNumberBox.Text);
                ShowNumberBox.Text = Convert.ToString(num1); 
                divde = 0;
                add = 0;
                minus = 0;
                xy = 0;
                
            }

            op = "*";
            extra = 1;
            
        }

        private void OneButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "1";
                History.Text = "1";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "1";
                    History.Text = History.Text + "1";
                    //History.Text = "1" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "1";
                    History.Text = History.Text + "1";
                    //History.Text = "1" + History.Text;
                }
                
            }
            extra = 0;
        }

        private void ZeroButton_Click(object sender, EventArgs e)
        {
            if (ShowNumberBox.Text == "0" && ShowNumberBox.Text != null)
            {
                ShowNumberBox.Text = "0";
                History.Text = "0";
            }
            else
            {
                if (extra == 1)
                {
                    ShowNumberBox.Text = "0";
                    History.Text = History.Text + "0";
                    //History.Text = "0" + History.Text;
                }
                else
                {
                    ShowNumberBox.Text = ShowNumberBox.Text + "0";
                    History.Text = History.Text + "0";
                    //History.Text = "0" + History.Text;
                }
            }
            extra = 0;
        }

        private void ShowNumberBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void History_TextChanged_1(object sender, EventArgs e)
        {

        }


    }
}
